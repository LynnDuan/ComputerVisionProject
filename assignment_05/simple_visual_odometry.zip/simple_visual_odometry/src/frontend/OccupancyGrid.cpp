#include "frontend/OccupancyGrid.h"
using namespace std;
using namespace cv;

OccupancyGrid::OccupancyGrid()
{
	initializer();
	// initializer1();
}

void OccupancyGrid::initializer1()
{

}

void OccupancyGrid::setImageSize1(size_t cols, size_t rows)
{

}

void OccupancyGrid::addPoint1(Point2f& p)
{
}

bool OccupancyGrid::isNewFeature1(Point2f& p)
{
	return true;
}

void OccupancyGrid::resetGrid1()
{

}

